package com.example.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import com.example.data.api.HomeAiApiService
import com.example.data.model.DesignStyle
import com.example.data.model.GeneratedDesign
import com.example.data.model.RoomType
import com.example.util.ImageUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class InteriorDesignRepository(
    private val apiService: HomeAiApiService = HomeAiApiService()
) {
    private val _recentDesigns = MutableStateFlow<List<GeneratedDesign>>(emptyList())
    val recentDesigns: StateFlow<List<GeneratedDesign>> = _recentDesigns.asStateFlow()

    suspend fun generateDesign(
        context: Context,
        originalUri: Uri?,
        originalBitmap: Bitmap?,
        roomType: RoomType,
        style: DesignStyle,
        instructions: String
    ): Result<GeneratedDesign> {
        val imageBytes = when {
            originalBitmap != null -> ImageUtils.bitmapToByteArray(originalBitmap)
            originalUri != null -> ImageUtils.uriToByteArray(context, originalUri)
            else -> return Result.failure(Exception("Please select a room photo first."))
        }

        if (imageBytes == null || imageBytes.isEmpty()) {
            return Result.failure(Exception("Unable to read selected photo data."))
        }

        val resolvedOriginalBitmap = originalBitmap ?: originalUri?.let { ImageUtils.uriToBitmap(context, it) }

        val apiResult = apiService.generateDesign(
            imageBytes = imageBytes,
            roomType = roomType.displayName,
            style = style.displayName,
            instructions = instructions.trim()
        )

        return apiResult.map { (generatedBitmap, base64) ->
            val design = GeneratedDesign(
                originalImageUri = originalUri,
                originalBitmap = resolvedOriginalBitmap,
                generatedBitmap = generatedBitmap,
                base64Data = base64,
                roomType = roomType,
                style = style,
                instructions = instructions.trim()
            )
            _recentDesigns.value = listOf(design) + _recentDesigns.value
            design
        }
    }

    suspend fun saveToGallery(context: Context, bitmap: Bitmap, title: String): Result<Uri> {
        return ImageUtils.saveBitmapToGallery(context, bitmap, title)
    }

    suspend fun shareDesign(context: Context, bitmap: Bitmap, caption: String) {
        ImageUtils.shareBitmap(context, bitmap, caption)
    }
}
