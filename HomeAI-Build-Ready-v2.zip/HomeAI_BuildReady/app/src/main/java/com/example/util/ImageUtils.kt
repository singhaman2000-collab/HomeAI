package com.example.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

object ImageUtils {

    suspend fun uriToByteArray(context: Context, uri: Uri): ByteArray? = withContext(Dispatchers.IO) {
        try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                inputStream.readBytes()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    suspend fun uriToBitmap(context: Context, uri: Uri): Bitmap? = withContext(Dispatchers.IO) {
        try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                BitmapFactory.decodeStream(inputStream)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun bitmapToByteArray(bitmap: Bitmap, quality: Int = 90): ByteArray {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, stream)
        return stream.toByteArray()
    }

    suspend fun saveBitmapToGallery(
        context: Context,
        bitmap: Bitmap,
        title: String = "HomeAI_Design_${System.currentTimeMillis()}"
    ): Result<Uri> = withContext(Dispatchers.IO) {
        try {
            val filename = "${title}.jpg"
            var outputStream: OutputStream? = null
            var imageUri: Uri? = null

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/HomeAI")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }

                val resolver = context.contentResolver
                imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                if (imageUri != null) {
                    outputStream = resolver.openOutputStream(imageUri)
                    if (outputStream != null) {
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 95, outputStream)
                    }
                    contentValues.clear()
                    contentValues.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(imageUri, contentValues, null, null)
                }
            } else {
                val imagesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString() + "/HomeAI"
                val file = File(imagesDir)
                if (!file.exists()) {
                    file.mkdirs()
                }
                val image = File(imagesDir, filename)
                outputStream = FileOutputStream(image)
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, outputStream)

                val contentValues = ContentValues().apply {
                    put(MediaStore.Images.Media.DATA, image.absolutePath)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                }
                imageUri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
            }

            outputStream?.close()

            if (imageUri != null) {
                Result.success(imageUri)
            } else {
                Result.failure(Exception("Could not create image file in gallery."))
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Result.failure(Exception("Failed to save to gallery: ${e.localizedMessage ?: "Unknown error"}"))
        }
    }

    suspend fun shareBitmap(context: Context, bitmap: Bitmap, caption: String = "Check out my new room design created with HomeAI!") {
        withContext(Dispatchers.IO) {
            try {
                val cachePath = File(context.cacheDir, "shared_images")
                cachePath.mkdirs()
                val file = File(cachePath, "homeai_design_${System.currentTimeMillis()}.jpg")
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
                }

                val contentUri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )

                if (contentUri != null) {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "image/jpeg"
                        putExtra(Intent.EXTRA_STREAM, contentUri)
                        putExtra(Intent.EXTRA_TEXT, caption)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    val chooser = Intent.createChooser(shareIntent, "Share Interior Design")
                    chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(chooser)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    /**
     * Creates aesthetic starter room templates for quick testing on emulators
     */
    fun createSampleRoomBitmap(type: String): Bitmap {
        val width = 1200
        val height = 900
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        when (type.lowercase()) {
            "bedroom" -> drawSampleBedroom(canvas, width, height)
            "kitchen" -> drawSampleKitchen(canvas, width, height)
            else -> drawSampleLivingRoom(canvas, width, height)
        }
        return bitmap
    }

    private fun drawSampleLivingRoom(canvas: Canvas, w: Int, h: Int) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // Walls
        paint.shader = LinearGradient(0f, 0f, 0f, h * 0.65f, Color.parseColor("#E2E8F0"), Color.parseColor("#CBD5E1"), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w.toFloat(), h * 0.65f, paint)
        paint.shader = null

        // Wooden Floor
        paint.shader = LinearGradient(0f, h * 0.65f, 0f, h.toFloat(), Color.parseColor("#A16207"), Color.parseColor("#78350F"), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, h * 0.65f, w.toFloat(), h.toFloat(), paint)
        paint.shader = null

        // Large Window
        paint.color = Color.parseColor("#93C5FD")
        canvas.drawRoundRect(RectF(w * 0.1f, h * 0.12f, w * 0.45f, h * 0.52f), 16f, 16f, paint)
        paint.color = Color.WHITE
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 14f
        canvas.drawRoundRect(RectF(w * 0.1f, h * 0.12f, w * 0.45f, h * 0.52f), 16f, 16f, paint)
        canvas.drawLine(w * 0.275f, h * 0.12f, w * 0.275f, h * 0.52f, paint)
        canvas.drawLine(w * 0.1f, h * 0.32f, w * 0.45f, h * 0.32f, paint)
        paint.style = Paint.Style.FILL

        // Wall Art Frame
        paint.color = Color.parseColor("#334155")
        canvas.drawRoundRect(RectF(w * 0.6f, h * 0.15f, w * 0.88f, h * 0.45f), 12f, 12f, paint)
        paint.color = Color.parseColor("#FDE68A")
        canvas.drawRoundRect(RectF(w * 0.62f, h * 0.17f, w * 0.86f, h * 0.43f), 8f, 8f, paint)

        // Rug
        paint.color = Color.parseColor("#E0E7FF")
        canvas.drawOval(RectF(w * 0.25f, h * 0.66f, w * 0.78f, h * 0.88f), paint)

        // Empty Sofa outline
        paint.color = Color.parseColor("#475569")
        canvas.drawRoundRect(RectF(w * 0.32f, h * 0.55f, w * 0.72f, h * 0.75f), 24f, 24f, paint)
        paint.color = Color.parseColor("#64748B")
        canvas.drawRoundRect(RectF(w * 0.35f, h * 0.50f, w * 0.69f, h * 0.65f), 16f, 16f, paint)

        // Floor Lamp
        paint.color = Color.parseColor("#1E293B")
        canvas.drawLine(w * 0.85f, h * 0.38f, w * 0.85f, h * 0.72f, paint)
        paint.color = Color.parseColor("#F59E0B")
        canvas.drawRoundRect(RectF(w * 0.81f, h * 0.32f, w * 0.89f, h * 0.40f), 8f, 8f, paint)
    }

    private fun drawSampleBedroom(canvas: Canvas, w: Int, h: Int) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = Color.parseColor("#F1F5F9")
        canvas.drawRect(0f, 0f, w.toFloat(), h * 0.65f, paint)
        paint.color = Color.parseColor("#D97706")
        canvas.drawRect(0f, h * 0.65f, w.toFloat(), h.toFloat(), paint)

        // Headboard & Bed
        paint.color = Color.parseColor("#334155")
        canvas.drawRoundRect(RectF(w * 0.3f, h * 0.35f, w * 0.7f, h * 0.55f), 16f, 16f, paint)
        paint.color = Color.parseColor("#FFFFFF")
        canvas.drawRoundRect(RectF(w * 0.28f, h * 0.52f, w * 0.72f, h * 0.82f), 20f, 20f, paint)
        paint.color = Color.parseColor("#93C5FD")
        canvas.drawRoundRect(RectF(w * 0.32f, h * 0.48f, w * 0.48f, h * 0.56f), 8f, 8f, paint)
        canvas.drawRoundRect(RectF(w * 0.52f, h * 0.48f, w * 0.68f, h * 0.56f), 8f, 8f, paint)
    }

    private fun drawSampleKitchen(canvas: Canvas, w: Int, h: Int) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = Color.parseColor("#F8FAFC")
        canvas.drawRect(0f, 0f, w.toFloat(), h * 0.65f, paint)
        paint.color = Color.parseColor("#475569")
        canvas.drawRect(0f, h * 0.65f, w.toFloat(), h.toFloat(), paint)

        // Cabinets & Countertop
        paint.color = Color.parseColor("#1E293B")
        canvas.drawRect(0f, h * 0.52f, w.toFloat(), h * 0.75f, paint)
        paint.color = Color.parseColor("#E2E8F0")
        canvas.drawRect(0f, h * 0.50f, w.toFloat(), h * 0.53f, paint)

        // Upper Cabinets
        paint.color = Color.parseColor("#0F172A")
        canvas.drawRect(w * 0.1f, h * 0.1f, w * 0.9f, h * 0.32f, paint)
    }
}
