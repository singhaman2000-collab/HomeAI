package com.example.data.api

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

class HomeAiApiService(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(90, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.HEADERS
        })
        .build()
) {
    companion object {
        private const val TAG = "HomeAiApiService"
        private const val GENERATE_URL = "https://homeai-backend.singhaman2000.workers.dev/generate"
    }

    suspend fun generateDesign(
        imageBytes: ByteArray,
        roomType: String,
        style: String,
        instructions: String
    ): Result<Pair<Bitmap, String>> = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "Preparing generate request: roomType=$roomType, style=$style, imageSize=${imageBytes.size} bytes")

            // Compress image to reasonable resolution for upload (max 1920x1920 to keep upload speedy and avoid payload limits)
            val optimizedBytes = prepareImagePayload(imageBytes)

            val imagePart = optimizedBytes.toRequestBody("image/jpeg".toMediaType())
            val requestBody = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("image", "room.jpg", imagePart)
                .addFormDataPart("roomType", roomType)
                .addFormDataPart("style", style)
                .addFormDataPart("instructions", instructions)
                .build()

            val request = Request.Builder()
                .url(GENERATE_URL)
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string() ?: ""
                Log.d(TAG, "Response code: ${response.code}, body length: ${responseBody.length}")

                if (!response.isSuccessful) {
                    val serverError = try {
                        val json = JSONObject(responseBody)
                        json.optString("error", json.optString("message", "Server error (${response.code})"))
                    } catch (e: Exception) {
                        "Server error (${response.code}): ${response.message.ifEmpty { "Please check connection" }}"
                    }
                    return@withContext Result.failure(Exception(serverError))
                }

                if (responseBody.isBlank()) {
                    return@withContext Result.failure(Exception("Empty response received from design server."))
                }

                val jsonObject = JSONObject(responseBody)
                val rawBase64 = jsonObject.optString("imageBase64", "")
                    .ifEmpty { jsonObject.optString("image", "") }

                if (rawBase64.isBlank()) {
                    val message = jsonObject.optString("message", "No image was returned in the server response.")
                    return@withContext Result.failure(Exception(message))
                }

                // Strip data URL prefix if present (e.g. data:image/png;base64,)
                val cleanBase64 = if (rawBase64.contains(",")) {
                    rawBase64.substringAfter(",")
                } else {
                    rawBase64
                }.replace("\n", "").replace("\r", "").trim()

                val decodedBytes = Base64.decode(cleanBase64, Base64.DEFAULT)
                val bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
                    ?: return@withContext Result.failure(Exception("Failed to decode the generated image."))

                Result.success(Pair(bitmap, cleanBase64))
            }
        } catch (e: java.net.SocketTimeoutException) {
            Log.e(TAG, "Timeout during AI generation", e)
            Result.failure(Exception("The AI design generation timed out. The model is busy, please try again in a moment."))
        } catch (e: java.net.UnknownHostException) {
            Log.e(TAG, "Network error", e)
            Result.failure(Exception("No internet connection. Please check your network and try again."))
        } catch (e: IOException) {
            Log.e(TAG, "IO error during AI generation", e)
            Result.failure(Exception("Network communication error: ${e.localizedMessage ?: "Please try again."}"))
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error during AI generation", e)
            Result.failure(Exception(e.localizedMessage ?: "An unexpected error occurred during generation."))
        }
    }

    private fun prepareImagePayload(inputBytes: ByteArray): ByteArray {
        val originalBitmap = BitmapFactory.decodeByteArray(inputBytes, 0, inputBytes.size) ?: return inputBytes
        val maxDimension = 1600
        val width = originalBitmap.width
        val height = originalBitmap.height

        val scaledBitmap = if (width > maxDimension || height > maxDimension) {
            val ratio = if (width > height) {
                maxDimension.toFloat() / width
            } else {
                maxDimension.toFloat() / height
            }
            val targetWidth = (width * ratio).toInt()
            val targetHeight = (height * ratio).toInt()
            Bitmap.createScaledBitmap(originalBitmap, targetWidth, targetHeight, true)
        } else {
            originalBitmap
        }

        val outputStream = ByteArrayOutputStream()
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 88, outputStream)
        return outputStream.toByteArray()
    }
}
