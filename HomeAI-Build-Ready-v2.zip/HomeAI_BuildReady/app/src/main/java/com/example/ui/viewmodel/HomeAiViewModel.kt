package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.DesignStyle
import com.example.data.model.GeneratedDesign
import com.example.data.model.RoomType
import com.example.data.repository.InteriorDesignRepository
import com.example.util.ImageUtils
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class ViewMode {
    EDITOR,
    RESULT
}

enum class ComparisonMode {
    SPLIT_SLIDER,
    SIDE_BY_SIDE,
    TOGGLE_TABS
}

data class HomeAiUiState(
    val viewMode: ViewMode = ViewMode.EDITOR,
    val selectedImageUri: Uri? = null,
    val selectedImageBitmap: Bitmap? = null,
    val selectedRoomType: RoomType = RoomType.LIVING_ROOM,
    val selectedStyle: DesignStyle = DesignStyle.MODERN,
    val specialInstructions: String = "",
    val isGenerating: Boolean = false,
    val generationProgressMessage: String = "",
    val currentDesign: GeneratedDesign? = null,
    val errorMessage: String? = null,
    val saveStatusMessage: String? = null,
    val isSaving: Boolean = false,
    val comparisonMode: ComparisonMode = ComparisonMode.SPLIT_SLIDER,
    val sliderPosition: Float = 0.5f,
    val showOriginalInTabs: Boolean = false
)

class HomeAiViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val repository = InteriorDesignRepository()

    private val _uiState = MutableStateFlow(HomeAiUiState())
    val uiState: StateFlow<HomeAiUiState> = _uiState.asStateFlow()

    val recentDesigns: StateFlow<List<GeneratedDesign>> = repository.recentDesigns

    private var progressJob: Job? = null

    fun onImageSelected(uri: Uri) {
        viewModelScope.launch {
            val bitmap = ImageUtils.uriToBitmap(getApplication(), uri)
            _uiState.update {
                it.copy(
                    selectedImageUri = uri,
                    selectedImageBitmap = bitmap,
                    errorMessage = null
                )
            }
        }
    }

    fun onSampleRoomSelected(roomName: String) {
        viewModelScope.launch {
            val bitmap = ImageUtils.createSampleRoomBitmap(roomName)
            _uiState.update {
                it.copy(
                    selectedImageUri = null,
                    selectedImageBitmap = bitmap,
                    errorMessage = null
                )
            }
        }
    }

    fun clearSelectedImage() {
        _uiState.update {
            it.copy(
                selectedImageUri = null,
                selectedImageBitmap = null
            )
        }
    }

    fun onRoomTypeSelected(roomType: RoomType) {
        _uiState.update { it.copy(selectedRoomType = roomType) }
    }

    fun onStyleSelected(style: DesignStyle) {
        _uiState.update { it.copy(selectedStyle = style) }
    }

    fun onSpecialInstructionsChanged(instructions: String) {
        _uiState.update { it.copy(specialInstructions = instructions) }
    }

    fun onInstructionChipTapped(chipText: String) {
        _uiState.update { current ->
            val currentText = current.specialInstructions.trim()
            val newText = if (currentText.isEmpty()) {
                chipText
            } else if (currentText.contains(chipText, ignoreCase = true)) {
                currentText
            } else {
                "$currentText, $chipText"
            }
            current.copy(specialInstructions = newText)
        }
    }

    fun generateAiDesign() {
        val state = _uiState.value
        if (state.selectedImageUri == null && state.selectedImageBitmap == null) {
            _uiState.update { it.copy(errorMessage = "Please select or upload a room photo first.") }
            return
        }

        _uiState.update {
            it.copy(
                isGenerating = true,
                errorMessage = null,
                generationProgressMessage = "Connecting to HomeAI engine..."
            )
        }

        // Start progressive loading stage messages
        progressJob?.cancel()
        progressJob = viewModelScope.launch {
            val stages = listOf(
                "Analyzing room layout and perspective...",
                "Detecting walls, windows, and architectural elements...",
                "Applying ${state.selectedStyle.displayName} materials and colors...",
                "Adding specialized furniture and textures...",
                "Balancing ambient daylight and lighting...",
                "Rendering photorealistic finish..."
            )
            for (stage in stages) {
                delay(2800)
                _uiState.update {
                    if (it.isGenerating) it.copy(generationProgressMessage = stage) else it
                }
            }
        }

        viewModelScope.launch {
            val result = repository.generateDesign(
                context = getApplication(),
                originalUri = state.selectedImageUri,
                originalBitmap = state.selectedImageBitmap,
                roomType = state.selectedRoomType,
                style = state.selectedStyle,
                instructions = state.specialInstructions
            )

            progressJob?.cancel()

            result.fold(
                onSuccess = { design ->
                    _uiState.update {
                        it.copy(
                            isGenerating = false,
                            currentDesign = design,
                            viewMode = ViewMode.RESULT,
                            errorMessage = null,
                            sliderPosition = 0.5f
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isGenerating = false,
                            errorMessage = error.localizedMessage ?: "Failed to generate design. Please check your connection and try again."
                        )
                    }
                }
            )
        }
    }

    fun saveDesignToGallery() {
        val design = _uiState.value.currentDesign ?: return
        _uiState.update { it.copy(isSaving = true, saveStatusMessage = null) }

        viewModelScope.launch {
            val title = "HomeAI_${design.roomType.name}_${design.style.name}_${System.currentTimeMillis()}"
            val result = repository.saveToGallery(
                context = getApplication(),
                bitmap = design.generatedBitmap,
                title = title
            )

            result.fold(
                onSuccess = {
                    _uiState.update {
                        it.copy(
                            isSaving = false,
                            saveStatusMessage = "Saved to Gallery (Pictures/HomeAI)!"
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isSaving = false,
                            saveStatusMessage = "Could not save: ${error.localizedMessage}"
                        )
                    }
                }
            )
        }
    }

    fun shareCurrentDesign() {
        val design = _uiState.value.currentDesign ?: return
        viewModelScope.launch {
            val caption = "Check out this ${design.style.displayName} ${design.roomType.displayName} created with HomeAI – Interior Designer!"
            repository.shareDesign(getApplication(), design.generatedBitmap, caption)
        }
    }

    fun setComparisonMode(mode: ComparisonMode) {
        _uiState.update { it.copy(comparisonMode = mode) }
    }

    fun setSliderPosition(pos: Float) {
        _uiState.update { it.copy(sliderPosition = pos.coerceIn(0f, 1f)) }
    }

    fun setShowOriginalInTabs(showOriginal: Boolean) {
        _uiState.update { it.copy(showOriginalInTabs = showOriginal) }
    }

    fun navigateToEditor() {
        _uiState.update { it.copy(viewMode = ViewMode.EDITOR) }
    }

    fun selectHistoryDesign(design: GeneratedDesign) {
        _uiState.update {
            it.copy(
                currentDesign = design,
                viewMode = ViewMode.RESULT,
                selectedRoomType = design.roomType,
                selectedStyle = design.style,
                specialInstructions = design.instructions,
                sliderPosition = 0.5f
            )
        }
    }

    fun dismissError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    fun dismissSaveStatus() {
        _uiState.update { it.copy(saveStatusMessage = null) }
    }
}
