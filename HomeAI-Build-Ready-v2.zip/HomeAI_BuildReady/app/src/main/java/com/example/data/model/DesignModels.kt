package com.example.data.model

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bathtub
import androidx.compose.material.icons.filled.Bed
import androidx.compose.material.icons.filled.Chair
import androidx.compose.material.icons.filled.Desk
import androidx.compose.material.icons.filled.Kitchen
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.ui.graphics.vector.ImageVector

enum class RoomType(
    val displayName: String,
    val description: String,
    val icon: ImageVector
) {
    LIVING_ROOM("Living Room", "Main seating, lounge, TV & family area", Icons.Default.Chair),
    BEDROOM("Bedroom", "Restful sanctuary, bed, closets & nightstands", Icons.Default.Bed),
    KITCHEN("Kitchen", "Cabinets, countertops, island & appliances", Icons.Default.Kitchen),
    BATHROOM("Bathroom", "Vanity, tiles, shower & modern fixtures", Icons.Default.Bathtub),
    DINING_ROOM("Dining Room", "Dining table, pendant lighting & credenza", Icons.Default.Restaurant),
    OFFICE("Office", "Work desk, ergonomic seating & bookshelf", Icons.Default.Desk);

    companion object {
        val ALL = entries.toList()
    }
}

enum class DesignStyle(
    val displayName: String,
    val subtitle: String,
    val keywords: String
) {
    MODERN("Modern", "Sleek lines, neutral tones & open spaces", "Clean lines, geometric forms, polished surfaces"),
    LUXURY("Luxury", "Opulent finishes, marble, brass & velvet", "Premium gold/brass accents, rich textures, marble"),
    MINIMALIST("Minimalist", "Clutter-free, functional & airy atmosphere", "Monochromatic, uncluttered, simple silhouettes"),
    SCANDINAVIAN("Scandinavian", "Light wood, cozy textiles & hygge warmth", "Light oak, muted pastels, cozy wool textures"),
    TRADITIONAL("Traditional", "Classic molding, rich woods & timeless elegance", "Crown molding, vintage charm, warm fabrics"),
    BOHO("Boho", "Earthy tones, rattan, macrame & lush plants", "Woven rattan, warm terracotta, indoor plants"),
    INDUSTRIAL("Industrial", "Exposed brick, black metal & raw textures", "Exposed brick, iron fixtures, rustic wood");

    companion object {
        val ALL = entries.toList()
    }
}

data class GeneratedDesign(
    val id: String = java.util.UUID.randomUUID().toString(),
    val originalImageUri: Uri? = null,
    val originalBitmap: Bitmap? = null,
    val generatedBitmap: Bitmap,
    val base64Data: String,
    val roomType: RoomType,
    val style: DesignStyle,
    val instructions: String,
    val timestamp: Long = System.currentTimeMillis()
)
