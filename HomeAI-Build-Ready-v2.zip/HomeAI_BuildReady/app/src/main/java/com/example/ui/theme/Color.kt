package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Indigo & Slate Theme
val Indigo900 = Color(0xFF1E1B4B)
val Indigo700 = Color(0xFF4338CA)
val Indigo600 = Color(0xFF4F46E5)
val Indigo500 = Color(0xFF6366F1)
val Indigo100 = Color(0xFFE0E7FF)
val Indigo50 = Color(0xFFEEF2FF)

// Warm Terracotta & Amber Accents
val Amber500 = Color(0xFFF59E0B)
val Amber600 = Color(0xFFD97706)
val Amber100 = Color(0xFFFEF3C7)
val Terracotta = Color(0xFFE06D53)
val SageGreen = Color(0xFF10B981)

// Neutral & Canvas Colors
val Slate950 = Color(0xFF020617)
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate400 = Color(0xFF94A3B8)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)
