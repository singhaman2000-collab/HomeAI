# HomeAI – Interior Designer

Native Android app generated in Google AI Studio and cleaned for standard Gradle builds.

## What is already connected
- Native Android photo picker
- Room type and design style selection
- Optional special instructions
- HomeAI Cloudflare backend
- AI-generated image response decoding
- Save/share generated design

## Backend used by the app
`https://homeai-backend.singhaman2000.workers.dev/generate`

## Build
This project uses Android SDK 36.
For a test install, build the `debug` APK. Debug builds use Android's normal debug signing rather than requiring an exported keystore.

## Privacy note
Room photos selected by a user are uploaded to the HomeAI backend for AI processing. Add a public privacy policy before wide distribution.
